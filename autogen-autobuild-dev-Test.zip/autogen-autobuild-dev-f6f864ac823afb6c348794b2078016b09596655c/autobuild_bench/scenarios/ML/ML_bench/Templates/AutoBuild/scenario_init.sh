pip install sympy matplotlib numpy
