pip install pandas beautifulsoup4 requests pytest
