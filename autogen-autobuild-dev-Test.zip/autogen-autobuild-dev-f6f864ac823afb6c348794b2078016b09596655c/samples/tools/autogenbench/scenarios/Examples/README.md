# Example Tasks

Various AutoGen example tasks. Unlike other benchmark tasks, these tasks have no automated evaluation.

## Running the tasks

```
autogenbench run Tasks/default_two_agents
```

Some tasks require a Bing API key. Edit the ENV.json file to provide a valid BING_API_KEY, or simply allow that task to fail (it is only required by one task).
