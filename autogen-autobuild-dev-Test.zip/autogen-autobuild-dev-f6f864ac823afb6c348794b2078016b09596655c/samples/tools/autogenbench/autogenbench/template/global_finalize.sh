# Global finalize.
